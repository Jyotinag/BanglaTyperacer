<?php
// Start the session
session_start();

$_SESSION["userEmail"] = "not found";
$_SESSION["userPassword"] = "not found";
//echo $_SESSION['userEmail'];
?>



<!DOCTYPE html>




<html>
<head>
<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>





<div class="header">
  <h1>BANGLA TYPE RACER</h1>
  <h2 id="typeShow"></h2>
  

<script>

var i = 0;
var txt = 'বাংলা টাইপিং গেম  : মজার খেলায় বাংলা শিখি';
var spd = 350;
var x = typeWriter();
function typeWriter() {
  if (i < txt.length) {
    document.getElementById("typeShow").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, spd);
  }
}


</script>
</div>

<div class="topnav">
  <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Register</button>
  <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>
  <button onClick="window.open('pp.php')" style="width:auto;">TUTORIAL</button>
  <button onclick="myAFunction()" style="width:auto;">Profile</button>
  <script>
function myAFunction(str) {
    window.open("http://localhost/REGISTER/profile.php");
}
</script>
</div>




<div class="row">
  <div class="leftcolumn">
		<div class="card">
	
<script>

var text = "";
var tim = 0;
var checkTimer = 0;
var timeleft = 0;
var downloadTimer;
var speed = 0;
var speedTimer;
var wpmspeed = 0;
var mywpmspeed = 0;
var checkmywpm = 0;
var textLength;
var wrongTextLength;

function one()
{
	var newButtonHost = '<button onclick="two()">Host</button>';
	var newButtonGuest = '<button onclick="three()">Guest</button>';
document.getElementById("a").innerHTML="Select your side."+newButtonHost+newButtonGuest;
}

function two()
{
document.getElementById("a").innerHTML="You are host.";
var multiPassageID = 4;
showHostID(multiPassageID);
}
function three()
{
document.getElementById("a").innerHTML="You are guest.";
document.getElementById("b").innerHTML = "";
showGuestID();	

}

function showHostID(multiStr) {
	
	
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				//var rspncHostID = this.responseText;
				
				//document.getElementById("b").innerHTML = rspncHostID;
				
				
				
				document.getElementById("multitxtHint").innerHTML = this.responseText;
				var rspnc = this.responseText;
				// Passage Finding
				var posStart = rspnc.indexOf("Content");
				posStart = posStart+9;
				var posEnd = rspnc.indexOf("About");
				posEnd = posEnd-5;
				
				// Passage Content
				//var text = "";
				var i;
				for (i = posStart; i <= posEnd; i++) {
					text += rspnc[i];
				}
				textLength = text.length;
				document.getElementById("multitxtHintChk").innerHTML = text;
				document.getElementById("multifname").value = "";
				document.getElementById("multimyText").innerHTML = "";
				document.getElementById("multitypeSpeed").textContent = 0;
				
				
            }
        };
		
        xmlhttp.open("GET","getHostID.php?q="+multiStr,true);
        xmlhttp.send();
    
}

function showGuestID() {
    var guestID = prompt("Please enter host id", "");
    if (guestID != null) {
        document.getElementById("b").innerHTML =
        "Host id : " + guestID ;
		
		checkHostID(guestID);
    }
}

function checkHostID(multiStr) {
	var rspncHostID;
	
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				rspncHostID = this.responseText;
				
				document.getElementById("c").innerHTML = rspncHostID;
            }
        };
		
        xmlhttp.open("GET","checkHostID.php?q="+multiStr,true);
        xmlhttp.send();
		
		if (rspncHostID.innerHTML > 0){
			document.getElementById("c") = "VALID";
			multishowUser(rspncHostID);
		}
    
}


function multimyFunction() {
	tim = tim+1;
    var x = document.getElementById("multifname").value;
	
	var len = x.length;
	var writeTextOK = "";
	var writeTextNotOK = "";
	var writeText = "";
	var ii;
	var chk = 0;
	for (ii = 0; ii <len; ii++) {
		if(text[ii]!=x[ii]){
			chk = 1;
		}
		if(chk == 0){
			writeTextOK +=x[ii];
		}
		else{
			writeTextNotOK +=x[ii];
		}
	}
	speed = writeTextOK.length;
	wrongTextLength = writeTextNotOK.length;
	
	writeTextNotOK = writeTextNotOK.fontcolor("red");
	writeTextOK = writeTextOK.fontcolor("green");
	writeText = writeTextOK.concat(writeTextNotOK);
    document.getElementById("multimyText").innerHTML = writeText;
	

			if((speed == textLength) && (wrongTextLength == 0))
			clearInterval(downloadTimer);
			
		
	// TIMER SET
	
	if( checkTimer >0){
	checkTimer =0
	
			downloadTimer = setInterval(function(){
		timeleft++;
		document.getElementById("multicountdowntimer").textContent = timeleft;
		// TYPING SPEED
		 wpmspeed = speed/timeleft;
		document.getElementById("multitypeSpeed").textContent = speed/timeleft;
		//mywpmspeed = wpmspeed;
		if(mywpmspeed < wpmspeed){
		
		mywpmspeed = wpmspeed;
		//document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed; 
	}
		document.getElementById("multimyWPM").innerHTML = mywpm + mywpmspeed;
		//if(timeleft >= 40)
		if(speed == textLength)
			clearInterval(downloadTimer);
			
		},1000);
	}
	//if(checkmywpm == 1){
		
		//document.getElementById("myWPM").innerHTML = mywpm + wpmspeed; 
	//}
	//document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed;
	
}




</script>

<div style="margin-left:15px; width:200px; margin-top:100px;">
<button onclick="one()">Multi </button>
</div>

<div style="margin-left:255px; width:200px; margin-top:-15px;">
</div>

<div id="entire" style="margin-left:490px; margin-top:-22px; width:400px; height:200px;"><div id="a"></div><div id="b"></div><div id="c"></div></div>

<br>
<div id="multitxtHint"><b>Information will be here...</b></div>

<br><br>
<div id="multitxtHintChk" class = a><b></b></div>

<br>


<p><font size="5" color="blue"> Total time <span id="multicountdowntimer">0 </span> Seconds</font></p>



Enter your Content: <input type="text" id="multifname" onkeyup="multimyFunction()">

<p><font size="5">Content is: <span id="multimyText"></span></font></p>

<br>
<p><font size="5" color="blue"> YOUR TYPING SPEED IS <span id="multitypeSpeed">0 </span> character per Seconds</font></p>
<br>

  
		</div>
  
  
  
  
  
  
    <div class="card">
	  
	 
<img src="banglaType.jpg" alt="Mountain View" width="850" height="250">
	  
      <br><br><br>
<button onclick="myFun()">RACE</button>
<script>
var numPass = 4;

function myFun() {
  showUser(numPass);
}
</script>
	

<br>
<div id="txtHint"><b>Information will be here...</b></div>

<br><br>
<div id="txtHintChk" class = a><b></b></div>

<br>


<p><font size="5" color="blue"> Total time <span id="countdowntimer">0 </span> Seconds</font></p>



Enter your Content: <input type="text" id="fname" onkeyup="myFunction()">

<p><font size="5">Content is: <span id="myText"></span></font></p>

<br>
<p><font size="5" color="blue"> YOUR TYPING SPEED IS <span id="typeSpeed">0 </span> character per Seconds</font></p>
<br>





<script>
var text = "";
var tim = 0;
var checkTimer = 0;
var timeleft = 0;
var downloadTimer;
var speed = 0;
var speedTimer;
var wpmspeed = 0;
var mywpmspeed = 0;
var checkmywpm = 0;
var textLength;
var wrongTextLength;
function showUser(str) {
	
	text = "";
    if (str == "") {
		checkTimer = 0;
		tim = 0;
		timeleft = 0;
        document.getElementById("txtHint").innerHTML = "";
		document.getElementById("txtHintChk").innerHTML = "";
		document.getElementById("myText").innerHTML = "";
		document.getElementById("fname").value = "";
		clearInterval(downloadTimer);
		document.getElementById("countdowntimer").textContent = timeleft;
        return;
    } else {
		checkTimer = 1;
		timeleft = 0;
		clearInterval(downloadTimer);
		document.getElementById("countdowntimer").textContent = timeleft;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
				var rspnc = this.responseText;
				// Passage Finding
				var posStart = rspnc.indexOf("Content");
				posStart = posStart+9;
				var posEnd = rspnc.indexOf("About");
				posEnd = posEnd-5;
				
				// Passage Content
				//var text = "";
				var i;
				for (i = posStart; i <= posEnd; i++) {
					text += rspnc[i];
				}
				textLength = text.length;
				document.getElementById("txtHintChk").innerHTML = text;
				document.getElementById("fname").value = "";
				document.getElementById("myText").innerHTML = "";
				document.getElementById("typeSpeed").textContent = 0;
            }
        };
		
        xmlhttp.open("GET","raceTestTwoGetPassage.php?q="+str,true);
        xmlhttp.send();
    }
}

function myFunction() {
	tim = tim+1;
    var x = document.getElementById("fname").value;
	
	var len = x.length;
	var writeTextOK = "";
	var writeTextNotOK = "";
	var writeText = "";
	var ii;
	var chk = 0;
	for (ii = 0; ii <len; ii++) {
		if(text[ii]!=x[ii]){
			chk = 1;
		}
		if(chk == 0){
			writeTextOK +=x[ii];
		}
		else{
			writeTextNotOK +=x[ii];
		}
	}
	speed = writeTextOK.length;
	wrongTextLength = writeTextNotOK.length;
	
	writeTextNotOK = writeTextNotOK.fontcolor("red");
	writeTextOK = writeTextOK.fontcolor("green");
	writeText = writeTextOK.concat(writeTextNotOK);
    document.getElementById("myText").innerHTML = writeText;
	

			if((speed == textLength) && (wrongTextLength == 0))
			clearInterval(downloadTimer);
			
		
	// TIMER SET
	
	if( checkTimer >0){
	checkTimer =0
	
			downloadTimer = setInterval(function(){
		timeleft++;
		document.getElementById("countdowntimer").textContent = timeleft;
		// TYPING SPEED
		 wpmspeed = speed/timeleft;
		document.getElementById("typeSpeed").textContent = speed/timeleft;
		//mywpmspeed = wpmspeed;
		if(mywpmspeed < wpmspeed){
		
		mywpmspeed = wpmspeed;
		//document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed; 
	}
		document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed;
		//if(timeleft >= 40)
		if(speed == textLength)
			clearInterval(downloadTimer);
			
		},1000);
	}
	//if(checkmywpm == 1){
		
		//document.getElementById("myWPM").innerHTML = mywpm + wpmspeed; 
	//}
	//document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed;
	
}

	   
function showWPM() {
	
	
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //document.getElementById("txtHint").innerHTML = this.responseText;
				var rspncWPM = this.responseText;
				// Passage Finding
				//var posStart = rspnc.indexOf("Content");
				//posStart = posStart+9;
				//var posEnd = rspnc.indexOf("About");
				//posEnd = posEnd-5;
				
				// Passage Content
				//var text = "";
				//var i;
				//for (i = posStart; i <= posEnd; i++) {
				//	text += rspnc[i];
				//}
				document.getElementById("demoWPM").innerHTML = rspncWPM;
            }
        };
		
        xmlhttp.open("GET","getWPM.php",true);
        xmlhttp.send();
    
}

function removeWPM() {
	
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				var rspncWPM = this.responseText;
				rspncWPM = ""
				document.getElementById("demoWPM").innerHTML = rspncWPM;
            }
        };
		
        xmlhttp.open("GET","getWPM.php",true);
        xmlhttp.send();
    
}
    
	

	
function showRecentWPM() {
	
	
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				var rspncWPM = this.responseText;
				
				document.getElementById("recentWPM").innerHTML = rspncWPM;
            }
        };
		
        xmlhttp.open("GET","getRecentWPM.php",true);
        xmlhttp.send();
    
}

function removeRecentWPM() {
	
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				var rspncWPM = this.responseText;
				rspncWPM = ""
				document.getElementById("recentWPM").innerHTML = rspncWPM;
            }
        };
		
        xmlhttp.open("GET","getWPM.php",true);
        xmlhttp.send();
    
}

</script>
	
	</div>
    <div class="card">
      <h1>TUTORIAL</h1>
      <h3>Bangla keyboards layouts...</h3>
      <div class="slideshow-container" style="height:350px;">
		
		<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="Avro.png" style="width:100%">
  <div class="text">Avro_Phonetic_Keyboard_Layout</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="Bijoy.png" style="width:100%">
  <div class="text">Bijoy_Bayanno_Keyboard_Layout</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="Bangladesh_National_Keyboard_Layout.png" style="width:100%">
  <div class="text">Bangladesh_National_Keyboard_Layout</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
		
		

	  </div>
      </div>
  </div>
  <div class="rightcolumn">
    <div class="card">
	<h3> TYPING IN BANGLA : TIPS AND TRICKS </h3>
      <iframe width="280" height="220" src="https://www.youtube.com/embed/je9_myKYAeY">
</iframe>
    </div>
	<br>
    <div class="topnav">
      <font color="red"><h3>Top Users</h3></font>
	  
	  


	  
      <button onclick="document.getElementById('demoWPM').innerHTML = showWPM()" style="width:auto;">Show</button>
	  <button onclick="document.getElementById('demoWPM').innerHTML = removeWPM()" style="width:auto;">Hide</button>
	  <button onclick="document.getElementById('demoWPM').innerHTML = showWPM()" style="width:auto;">Refresh</button>
	  <font color="blue"><p id="demoWPM"></p></font>
	
    </div><br>
	<div class="topnav">
      <font color="red"><h3>Recent Users</h3></font>
	  
	  


	  
      <button onclick="document.getElementById('recentWPM').innerHTML = showRecentWPM()" style="width:auto;">Show</button>
	  <button onclick="document.getElementById('recentWPM').innerHTML = removeRecentWPM()" style="width:auto;">Hide</button>
	  <button onclick="document.getElementById('recentWPM').innerHTML = showRecentWPM()" style="width:auto;">Refresh</button>
	  <font color="blue"><p id="recentWPM"></p></font>
	
    </div>
    <div class="card">
	  <iframe style="height: 650px; 
    width: 290px;
    background-color: powderblue" src="formpage.html" name="targetframe"  frameborder="0" >
    </iframe>
    </div>
  </div>
</div>
<div id="id01" class="modal">
  
  <form class="modal-content animate" action="login_check.php" method="post" accept-charset="utf-8">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="login.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
	<label>Email:</label>
<input class="input" name="email" type="text" value="" required>
<label>Password:</label>
<input class="input" name="password" type="password" value="" required>

<input class="submit" name="submit" type="submit" value="Submit">
	  
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

<script>


</script>

<div class="footer">
  <h2>Footer</h2>
</div>

</body>
</html>
