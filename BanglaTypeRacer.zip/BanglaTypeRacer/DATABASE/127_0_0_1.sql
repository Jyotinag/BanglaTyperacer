-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2018 at 03:30 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bangla`
--
CREATE DATABASE IF NOT EXISTS `bangla` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bangla`;

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE `information` (
  `name` varchar(44) NOT NULL,
  `email` varchar(44) NOT NULL,
  `contact` varchar(44) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`name`, `email`, `contact`) VALUES
('hasan', '', ''),
('hasan', 'hasan@gmail.com', '4567'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('à¦¹à¦¾à¦¸à¦¾à¦¨', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡'),
('hasan', 'à¦¹à¦¾à¦¸à¦¾à¦¨@gmail.com', 'à¦à¦•à¦¦à§à¦‡45');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `ID` int(6) DEFAULT NULL,
  `Name` varchar(44) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- Database: `banglatype`
--
CREATE DATABASE IF NOT EXISTS `banglatype` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `banglatype`;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `author` varchar(100) NOT NULL,
  `book` varchar(100) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `about` varchar(5000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `author`, `book`, `content`, `about`) VALUES
(1, 'রবীন্দ্রনাথ ঠাকুর', 'জাতীয় সঙ্গীত', 'আমার সোনার বাংলা, আমি তোমায় ভালবাসি। চিরদিন তোমার আকাশ, তোমার বাতাস, আমার প্রাণে বাজায় বাঁশি।', 'রবীন্দ্রনাথ ঠাকুর রচিত বাংলাদেশের জাতীয় সঙ্গীত।'),
(2, 'রুদ্র মোহাম্মদ শহীদুল্লাহ', 'তোমাকে চাই (অ্যালবাম)', 'ভালো আছি, ভালো থেকো, আকাশের ঠিকানায় চিঠি লিখো দিও তোমার মালা খানি। বাউলের এই মনটারে ভিতরে বাহিরে আন্তরে অন্তরে আছো তুমি হৃদয় জুড়ে।', 'রুদ্র মোহাম্মদ শহীদুল্লাহ রচিত এই গানের সুরকারঃ আহমেদ ইমতিয়াজ বুলবল এবং শিল্পীঃ এন্ড্রু কিশোর ও কনক চাঁপা'),
(3, 'হুমায়ূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম', 'আজকের দিনটা এত সুন্দর কেন? সকালবেলা জানালা খুলে আমি হতভম্ব। এ কী! আকাশ এত নীল! আকাশের তো এত নীল হবার কথা না।', 'হিমুর হাতে কয়েকটি নীলপদ্ম ১৯৯৬ সালে প্রকাশিত হিমু সিরিজের ৬ষ্ঠ বই। '),
(4, 'হুমায়ূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম', 'গল্প-উপন্যাসে “পাখি-ডাকা ভোর” বাক্যটা প্রায়ই পাওয়া যায় । যারা ভোরবেলা পাখির ডাক শোনেন না তাদের কাছে ‘পাখি-ডাকা ভোরের” রোমান্টিক আবেদন আছে। লেখকরা কিন্তু পাঠকদের বিভ্রান্ত করেন- তারা পাখি-ডাকা ভোর বাক্যটায় পাখির নাম বলেন না। ভোরবেলা যে-পাখি ডাকে তার নাম কাক ।', 'হিমুর হাতে কয়েকটি নীলপদ্ম ১৯৯৬ সালে প্রকাশিত হিমু সিরিজের ৬ষ্ঠ বই।'),
(6, 'হুমায়ূন আহমেদ', 'কবি', 'সুবর্ণের বর্ষা সংখ্যা বের হয়েছে। প্রচ্ছদে কদম গাছের ছবি। ফটোগ্রাফকে কি কায়দা করেছে, দেখে মনে হয় জলরঙে আঁকা ছবি। আতাহারের মনে হল, লোকজন প্রচ্ছদ দেখেই পত্রিকা কিনে ফেলবে। হু হু করে সুবর্ণ বিক্রি হয়ে যাবে।', '১৯৯৬ সালে প্রকাশিত হুমায়ূন আহমেদের একটি উপন্যাস। '),
(7, 'হুমায়ূন আহমেদ', 'শ্রাবণমেঘের দিন', 'পায়ের কাছে প্রকাণ্ড জানালা। শহরের গ্রীলদেয়া জানালা না, খোলামেলা জানালা। এত প্রকাণ্ড জানালা যে মনে হয় আকাশটা জানালা গলে ঘরের ভেতর ঢুকে পড়ার চেষ্টা করছে। ঘন নীল আকাশ, যেন কিছুক্ষণ আগে গাদাখানিক নীল রঙ আকাশে লাগানো হয়েছে। রঙ এখনও শুকায়নি।', 'শ্রাবণমেঘের দিন ১৯৯৪ সালে প্রকাশিত হুমায়ূন আহমেদের একটি উপন্যাস।'),
(5, 'হুমায়ূন আহমেদ', 'বৃষ্টি বিলাস', 'মিথ্যা দু’রকমের আছে। হঠাৎ মুখে এসে যাওয়া মিথ্যা, আর ভেবে চিন্তে বলা মিথ্যা। হঠাৎ মিথ্যা আপনা আপনি মুখে এসে যায়। কোনো পরিশ্রম করতে হয় না। ভেবে চিন্তে মিথ্যা বলাটাই কঠিন। এই মিথ্যা সহজে গলায় আসে না। বারবার মুখে আটকে যায়।', 'বৃষ্টি বিলাস ২০০০ সালে প্রকাশিত হয়। হুমায়ূন আহমেদ রচিত এই উপন্যাসের অন্যতম চরিত্র \'শামা\'।'),
(8, 'বঙ্কিমচন্দ্র চট্টোপাধ্যায়', 'বিষবৃক্ষ', 'হীরার কলহ–বিষবৃক্ষের মুকুল তা ত হলো। কুন্দ বশ হবে! কিন্তু সূর্যমুখী নগেন্দ্রের দুই চক্ষের বিষ না হলে ত কিছুতেই কিছু হবে না। গোড়ার কাজ সেই। হীরা এক্ষণে তাহাদের অভিন্ন হৃদয় ভিন্ন করিবার চেষ্টায় রহিল।', 'সামাজিক উপন্যাস। বঙ্গদর্শন পত্রিকার প্রথম সংখ্যা (বৈশাখ, ১২৭৯) থেকে ধারাবাহিক প্রকাশিত হয়। মোট সংস্করণের সংখ্যা আট। সর্বশেষ সংস্করণ মুদ্রিত হয় ১৮৯২ সালে।'),
(9, 'বঙ্কিমচন্দ্র চট্টোপাধ্যায়', 'আনন্দমঠ', '১১৭৬ সালে গ্রীষ্মকালে এক দিন পদচিহ্ন গ্রামে রৌদ্রের উত্তাপ বড় প্রবল। গ্রামখানি গৃহময়, কিন্তু লোক দেখি না। বাজারে সারি সারি দোকান, হাটে সারি সারি চালা, পল্লীতে পল্লীতে শত শত মৃন্ময় গৃহ, মধ্যে মধ্যে উচ্চ নীচ অট্টালিকা। আজ সব নীরব।', 'বঙ্কিমচন্দ্রের প্রসিদ্ধ ঐতিহাসিক উপন্যাস। প্রথম প্রকাশ বঙ্গদর্শন পত্রিকায় (চৈত্র, ১২৮৭ – জ্যৈষ্ঠ, ১২৮৯)।-১৮৯২ সালে মুদ্রিত। ভারতীয় প্রজাতন্ত্রের জাতীয় স্তোত্র বন্দেমাতরমএই উপন্যাস থেকে গৃহীত।\r\nছিয়াত্তরের মন্বন্তরের পটভূমিকায় সন্যাসী বিদ্রোহের ছায়া অবলম্বনে রচিত। এই উপন্যাসে লেখকের দেশপ্রেম ফুটে উঠেছে।'),
(10, 'কাজী নজরুল ইসলাম', 'ব্যথার দান', 'গোলেস্তান তুমি কি সেই গোলেস্তান? তবে আজ তুমি এত বিশ্রী কেন? তোমার ফুলে সে সৌন্দর্য নেই, শুধু তাতে নরকের নাড়ি-উঠে আসা পূতিগন্ধ! তোমার আকাশ আর তেমন উদার নয়, কে যেন তাকে পঙ্কিল ঘোলাটে করে দিয়েছে! তোমার মলয় বাতাসে যেন লক্ষ হাজার কাচের টুকরো লুকিয়ে রয়েছে!', 'ব্যথার দান (১৯২২) গল্পগ্রন্থ, কাজী নজরুল ইসলাম।');

-- --------------------------------------------------------

--
-- Table structure for table `multiplayer`
--

CREATE TABLE `multiplayer` (
  `id` int(11) NOT NULL,
  `host` int(11) NOT NULL,
  `guest` int(11) NOT NULL,
  `passageID` int(11) NOT NULL,
  `hostwpm` int(11) NOT NULL,
  `guestwpm` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `multiplayer`
--

INSERT INTO `multiplayer` (`id`, `host`, `guest`, `passageID`, `hostwpm`, `guestwpm`) VALUES
(1, 1, 0, 4, 15, 0),
(2, 2, 2, 4, 24, 9),
(3, 3, 0, 4, 5, 0),
(4, 4, 4, 4, 24, 16),
(5, 5, 0, 4, 0, 0),
(6, 6, 0, 4, 0, 0),
(7, 7, 7, 4, 0, 0),
(8, 8, 0, 4, 9, 0),
(9, 9, 0, 4, 26, 0),
(10, 10, 0, 4, 12, 0),
(11, 11, 11, 4, 10, 24),
(12, 12, 12, 7, 7, 16),
(13, 13, 0, 7, 0, 0),
(14, 14, 14, 7, 0, 0),
(15, 15, 0, 7, 0, 0),
(16, 16, 0, 7, 0, 0),
(17, 17, 0, 7, 0, 0),
(18, 18, 0, 7, 0, 0),
(19, 19, 0, 7, 0, 0),
(20, 20, 0, 7, 0, 0),
(21, 21, 0, 7, 0, 0),
(22, 22, 0, 7, 0, 0),
(23, 23, 0, 7, 0, 0),
(24, 24, 0, 2, 0, 0),
(25, 25, 0, 9, 0, 0),
(26, 26, 0, 8, 0, 0),
(27, 27, 0, 8, 2, 0),
(28, 28, 0, 8, 4, 0),
(29, 29, 0, 6, 0, 0),
(30, 30, 30, 8, 7, 8),
(31, 31, 0, 7, 9, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'mahmudul@gmail.com', '$2y$12$ViusrAJlxqZ4xGDnHA4KFOXAKp9/tWbRrggWDVfFrX6LajeGezbsW', '2018-05-05 04:00:01'),
(2, 'nag@gmail.com', '$2y$12$fufiyTshdIISIA7tAZMQ9ut6gFNsCaP9TSWmdcg603m2NU4Z.lf4a', '2018-05-05 04:02:45');

-- --------------------------------------------------------

--
-- Table structure for table `wpm`
--

CREATE TABLE `wpm` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `wpm` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wpm`
--

INSERT INTO `wpm` (`id`, `email`, `content`, `wpm`) VALUES
(6, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 5),
(5, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 2),
(4, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীতজাতীয় সঙ্গীত', 2),
(3, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীতজাতীয় সঙ্গীত', 2),
(2, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 4),
(1, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 4),
(7, 'mahmudul@gmail.com', '', 5),
(8, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 0),
(9, 'mahmudul@gmail.com', '', 0),
(10, 'mahmudul@gmail.com', '', 0),
(11, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 7),
(12, 'mahmudul@gmail.com', '', 7),
(13, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 1),
(14, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 3),
(15, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 7),
(16, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 24),
(17, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 8),
(18, 'mahmudul@gmail.com', 'জাতীয় সঙ্গীত', 24),
(19, 'nag@gmail.com', 'জাতীয় সঙ্গীত', 5),
(20, 'nag@gmail.com', 'বিষবৃক্ষ', 10),
(21, 'nag@gmail.com', 'হিমুর হাতে কয়েকটি নীলপদ্ম', 0),
(22, 'nag@gmail.com', 'শ্রাবণমেঘের দিন', 13),
(23, 'nag@gmail.com', 'আনন্দমঠ', 19);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"banglatype\",\"table\":\"multiplayer\"},{\"db\":\"banglatype\",\"table\":\"wpm\"},{\"db\":\"banglatype\",\"table\":\"content\"},{\"db\":\"testbangla\",\"table\":\"multiplayer\"},{\"db\":\"testbangla\",\"table\":\"wpm\"},{\"db\":\"banglatype\",\"table\":\"users\"},{\"db\":\"banglatype\",\"table\":\"register\"},{\"db\":\"testbangla\",\"table\":\"content\"},{\"db\":\"testbangla\",\"table\":\"input\"},{\"db\":\"testbangla\",\"table\":\"inputbangla\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2018-04-01 15:47:26', '[]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
--
-- Database: `testbangla`
--
CREATE DATABASE IF NOT EXISTS `testbangla` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `testbangla`;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `author` varchar(200) NOT NULL,
  `book` varchar(200) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `about` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `author`, `book`, `content`, `about`) VALUES
(1, 'হুমাযূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম', '\"যাবার আগে আপনি বলে যাবেন আপনি কে?\"  আমি বললাম,\"মারিয়া আমি কেউ না। I am Nobody.\" আমি আমার এক জীবনে অনেককে এই কথা বলেছি-কখনো আমার গলা ধরে যায়নি, বা চোখ ভিজে ওঠেনি। দু’টো ব্যাপারই এই প্রখম ঘটল।', '\'হিমুর হাতে কয়েকটি নীলপদ্ম\' ১৯৯৬ সালে প্রকাশিত হিমু সিরিজের ৬ষ্ঠ বই। '),
(2, ' হুমায়ূন আহমেদ', 'ময়ূরাক্ষী', 'স্যার যেদিন মারা যান সেই রাত্রিতেই আমি প্রথম ময়ূরাক্ষী নদীটা স্বপ্নে দেখি। ছোট্ট একটা নদী। তার পানি কাঁচের মত স্বচ্ছ। নিচের বালিগুলো পর্যন্ত স্পষ্ট দেখা যায়।', 'ময়ূরাক্ষী (১৯৯০) - হুমায়ূন আহমেদের লেখা হিমু সিরিজের প্রথম বই।'),
(3, 'শীমা', 'বেতারা', 'বাংলা আমার মায়ের ভাষা\r\nবাংলা আমার দেশ\r\nএই ভাষাতে কথা বলে\r\nআনন্দ পাই বেশ', 'ছড়াগান'),
(4, 'বাংলা ', 'বাংলা ', 'বাংলা বাংলা বাংলা বাংলা বাংলা', 'বাংলা ');

-- --------------------------------------------------------

--
-- Table structure for table `input`
--

CREATE TABLE `input` (
  `id` int(11) NOT NULL,
  `text` varchar(444) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `inputbangla`
--

CREATE TABLE `inputbangla` (
  `name` varchar(44) NOT NULL,
  `email` varchar(44) NOT NULL,
  `contact` varchar(44) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inputbangla`
--

INSERT INTO `inputbangla` (`name`, `email`, `contact`) VALUES
('hasan', 'hasan@gmail.com', '4567'),
('hasan', 'hasan@gmail.com', '4567'),
('হাসান', 'hasan@gmail.com', '4567'),
('হাসান', 'হাসান@gmail.com', 'একদুই45'),
('hasan', 'hasan@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`email`, `password`) VALUES
('hasan@gmail.com', 'হাসান'),
('mah@gmail.com', 'mah'),
('mah@gmail.com', 'mah'),
('mah@gmail.com', 'mah'),
('mah@gmail.com', 'mah'),
('mah@gmail.com', 'maha'),
('mah@gmail.com', 'mah'),
('mah@gmail.com', 'aaa'),
('as', 'ass'),
('mah@gmail.com', 'mah');

-- --------------------------------------------------------

--
-- Table structure for table `multiplayer`
--

CREATE TABLE `multiplayer` (
  `id` int(11) NOT NULL,
  `host` int(11) NOT NULL,
  `guest` int(11) NOT NULL,
  `passageID` int(11) NOT NULL,
  `hostWPM` double(11,2) NOT NULL,
  `guestWPM` double(11,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `multiplayer`
--

INSERT INTO `multiplayer` (`id`, `host`, `guest`, `passageID`, `hostWPM`, `guestWPM`) VALUES
(1, 1, 0, 4, 0.00, 0.00),
(2, 2, 0, 4, 0.00, 0.00),
(3, 3, 0, 4, 0.00, 0.00),
(4, 4, 4, 4, 0.00, 0.00),
(5, 5, 5, 4, 0.00, 0.00),
(6, 6, 0, 4, 0.00, 0.00),
(7, 7, 0, 4, 0.00, 0.00),
(8, 8, 0, 4, 0.00, 0.00),
(9, 9, 0, 4, 0.00, 0.00),
(10, 10, 0, 4, 0.00, 0.00),
(11, 11, 0, 4, 0.00, 0.00),
(12, 12, 0, 4, 0.00, 0.00),
(13, 13, 0, 4, 0.00, 0.00),
(14, 14, 0, 4, 0.00, 0.00),
(15, 15, 0, 4, 0.00, 0.00),
(16, 16, 0, 4, 0.00, 0.00),
(17, 17, 0, 4, 0.00, 0.00),
(18, 18, 0, 4, 0.00, 0.00),
(19, 19, 0, 4, 0.00, 0.00),
(20, 20, 0, 4, 0.00, 0.00),
(21, 21, 0, 4, 0.00, 0.00),
(22, 22, 0, 4, 0.00, 0.00),
(23, 23, 0, 4, 0.00, 0.00),
(24, 24, 0, 4, 0.00, 0.00),
(25, 25, 0, 4, 0.00, 0.00),
(26, 26, 0, 4, 0.00, 0.00),
(27, 27, 0, 4, 0.00, 0.00),
(28, 28, 0, 4, 0.00, 0.00),
(29, 29, 0, 4, 0.00, 0.00),
(30, 30, 0, 4, 0.00, 0.00),
(31, 31, 0, 4, 0.00, 0.00),
(32, 32, 0, 4, 0.00, 0.00),
(33, 33, 0, 4, 0.00, 0.00),
(34, 34, 0, 4, 0.00, 0.00),
(35, 35, 0, 4, 0.00, 0.00),
(36, 36, 0, 4, 0.00, 0.00),
(37, 37, 0, 4, 0.00, 0.00),
(38, 38, 0, 4, 0.00, 0.00),
(39, 39, 0, 4, 0.00, 0.00),
(40, 40, 0, 4, 0.00, 0.00),
(41, 41, 0, 4, 0.00, 0.00),
(42, 42, 0, 4, 0.00, 0.00),
(43, 43, 43, 4, 0.00, 0.00),
(44, 44, 44, 4, 0.00, 0.00),
(45, 45, 0, 4, 0.00, 0.00),
(46, 46, 0, 4, 0.00, 0.00),
(47, 47, 0, 4, 0.00, 0.00),
(48, 48, 0, 4, 0.00, 0.00),
(49, 49, 0, 4, 0.00, 0.00),
(50, 50, 0, 4, 0.00, 0.00),
(51, 51, 0, 4, 0.00, 0.00),
(52, 52, 0, 4, 0.00, 0.00),
(53, 53, 0, 4, 0.00, 0.00),
(54, 54, 54, 4, 4.00, 2.18),
(55, 55, 55, 4, 0.41, 0.00),
(56, 56, 56, 4, 0.00, 5.75),
(57, 57, 57, 4, 8.00, 0.00),
(58, 58, 58, 4, 1.16, 0.00),
(59, 59, 59, 4, 0.00, 0.00),
(60, 60, 60, 4, 0.80, 0.60),
(61, 61, 0, 4, 0.00, 0.00),
(62, 62, 0, 4, 0.00, 0.00),
(63, 63, 0, 4, 0.00, 0.00),
(64, 64, 0, 4, 0.00, 0.00),
(65, 65, 65, 4, 0.00, 0.00),
(66, 66, 66, 4, 0.00, 0.00),
(67, 67, 0, 4, 0.00, 0.00),
(68, 68, 0, 4, 0.00, 0.00),
(69, 69, 0, 4, 0.00, 0.00),
(70, 70, 70, 4, 0.00, 0.00),
(71, 71, 0, 4, 0.00, 0.00),
(72, 72, 0, 4, 0.00, 0.00),
(73, 73, 0, 4, 0.00, 0.00),
(74, 74, 74, 4, 0.00, 0.00),
(75, 75, 0, 4, 0.00, 0.00),
(76, 76, 0, 4, 0.00, 0.00),
(77, 77, 77, 4, 0.00, 0.00),
(78, 78, 0, 4, 0.00, 0.00),
(79, 79, 0, 4, 0.00, 0.00),
(80, 80, 0, 4, 0.00, 0.00),
(81, 81, 0, 4, 0.00, 0.00),
(82, 82, 0, 4, 0.00, 0.00),
(83, 83, 0, 4, 0.00, 0.00),
(84, 84, 0, 4, 0.00, 0.00),
(85, 85, 0, 4, 0.00, 0.00),
(86, 86, 0, 4, 0.00, 0.00),
(87, 87, 0, 4, 0.00, 0.00),
(88, 88, 0, 4, 0.00, 0.00),
(89, 89, 0, 4, 0.00, 0.00),
(90, 90, 0, 4, 0.00, 0.00),
(91, 91, 0, 4, 0.00, 0.00),
(92, 92, 0, 4, 0.00, 0.00),
(93, 93, 0, 4, 0.00, 0.00),
(94, 94, 0, 4, 0.00, 0.00),
(95, 95, 0, 4, 0.00, 0.00),
(96, 96, 0, 4, 0.00, 0.00),
(97, 97, 0, 4, 0.00, 0.00),
(98, 98, 0, 4, 1.71, 0.00),
(99, 99, 0, 4, 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `passage`
--

CREATE TABLE `passage` (
  `id` int(11) NOT NULL,
  `content` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `passage`
--

INSERT INTO `passage` (`id`, `content`) VALUES
(1, 'My name is Hasan. রবিবার ক্লাস ছুটি... :D'),
(2, 'Bangladesh is an independent country. '),
(3, 'স্যার যেদিন মারা যান সেই রাত্রিতেই আমি প্রথম ময়ূরাক্ষী নদীটা স্বপ্নে দেখি। ছোট্ট একটা নদী। তার পানি কাঁচের মত স্বচ্ছ। নিচের বালিগুলো পর্যন্ত স্পষ্ট দেখা যায়। নদীর দুইধারে দূর্বাঘাসগুলো কী সবুজ! কী কোমল! নদীর ঐ পাড়ে বিশাল ছায়াময় একটা পাকুড় গাছ। সেই গাছে বিষণ্ণ গলায় একটা ঘুঘু ডাকছে। সেই ডাকে একধরনের কান্না মিশে আছে।'),
(1, 'স্যার যেদিন মারা যান সেই রাত্রিতেই আমি প্রথম ময়ূরাক্ষী নদীটা স্বপ্নে দেখি। ছোট্ট একটা নদী। তার পানি কাঁচের মত স্বচ্ছ। নিচের বালিগুলো পর্যন্ত স্পষ্ট দেখা যায়। নদীর দুইধারে দূর্বাঘাসগুলো কী সবুজ! কী কোমল! নদীর ঐ পাড়ে বিশাল ছায়াময় একটা পাকুড় গাছ। সেই গাছে বিষণ্ণ গলায় একটা ঘুঘু ডাকছে। সেই ডাকে একধরনের কান্না মিশে আছে।'),
(2, 'আমি কখনো রূপাকে চিঠি লিখি নি। একবার হঠাৎ একটি চিঠি লিখতে ইচ্ছা হলো । লিখতে বসে দেখি কী লিখব ভেবে পাচ্ছি না। অনেকবার করে একটি লাইন লিখলাম : \"রূপা তুমি কেমন আছ?\"  সমস্ত পাতা জুড়ে একটি মাত্র বাক্য।'),
(1, '\"যাবার আগে আপনি বলে যাবেন আপনি কে?\"  আমি বললাম,\"মারিয়া আমি কেউ না। I am Nobody.\" আমি আমার এক জীবনে অনেককে এই কথা বলেছি-কখনো আমার গলা ধরে যায়নি, বা চোখ ভিজে ওঠেনি। দু’টো ব্যাপারই এই প্রখম ঘটল।'),
(1, '\"যাবার আগে আপনি বলে যাবেন আপনি কে?\"  আমি বললাম,\"মারিয়া আমি কেউ না। I am Nobody.\" আমি আমার এক জীবনে অনেককে এই কথা বলেছি-কখনো আমার গলা ধরে যায়নি, বা চোখ ভিজে ওঠেনি। দু’টো ব্যাপারই এই প্রখম ঘটল।'),
(1, '\"যাবার আগে আপনি বলে যাবেন আপনি কে?\"  আমি বললাম,\"মারিয়া আমি কেউ না। I am Nobody.\" আমি আমার এক জীবনে অনেককে এই কথা বলেছি-কখনো আমার গলা ধরে যায়নি, বা চোখ ভিজে ওঠেনি। দু’টো ব্যাপারই এই প্রখম ঘটল।'),
(1, '\"যাবার আগে আপনি বলে যাবেন আপনি কে?\"  আমি বললাম,\"মারিয়া আমি কেউ না। I am Nobody.\" আমি আমার এক জীবনে অনেককে এই কথা বলেছি-কখনো আমার গলা ধরে যায়নি, বা চোখ ভিজে ওঠেনি। দু’টো ব্যাপারই এই প্রখম ঘটল।'),
(1, 'ৌ'),
(1, '\"যাবার আগে আপনি বলে যাবেন আপনি কে?\"  আমি বললাম,\"মারিয়া আমি কেউ না। I am Nobody.\" আমি আমার এক জীবনে অনেককে এই কথা বলেছি-কখনো আমার গলা ধরে যায়নি, বা চোখ ভিজে ওঠেনি। দু’টো ব্যাপারই এই প্রখম ঘটল।'),
(2, 'মারিয়া বলল, বসুন। তার চোখমুখ কঠিন, তবু মনে হলো সেই কাঠিন্যের আড়ালে চাপা হাসি ঝিকমিক করছে। সে সুন্দর একটা শাড়ি পরেছে। চাপা রঙের শাড়ি । রঙটা এমন যে মনে হচ্ছে ঘরে চাপাফুলের গন্ধ পাচ্ছি।'),
(2, 'মারিয়া বলল, বসুন। তার চোখমুখ কঠিন, তবু মনে হলো সেই কাঠিন্যের আড়ালে চাপা হাসি ঝিকমিক করছে। সে সুন্দর একটা শাড়ি পরেছে। চাপা রঙের শাড়ি । রঙটা এমন যে মনে হচ্ছে ঘরে চাপাফুলের গন্ধ পাচ্ছি।'),
(2, 'স্যার যেদিন মারা যান সেই রাত্রিতেই আমি প্রথম ময়ূরাক্ষী নদীটা স্বপ্নে দেখি। ছোট্ট একটা নদী। তার পানি কাঁচের মত স্বচ্ছ। নিচের বালিগুলো পর্যন্ত স্পষ্ট দেখা যায়।');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`name`, `email`, `password`) VALUES
('hasan', 'hasan@gmail.com', 'hasan'),
('hasan', 'hasan@gmail.com', 'hasan'),
('হাসান', 'হাসান@gmail.com', 'hasan'),
('hasan', 'হাসান@gmail.com', 'হাসান'),
('Mahmudul Hasan', 'mahmudul@gmail.com', 'mah56'),
('Mahmudul', 'mah@gmail.com', 'mah'),
('nag', 'nag.csedu', 'asdg'),
('asasaas', 'asasasasas', 'asasas');

-- --------------------------------------------------------

--
-- Table structure for table `source`
--

CREATE TABLE `source` (
  `id` int(11) NOT NULL,
  `author` varchar(50) NOT NULL,
  `book` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `source`
--

INSERT INTO `source` (`id`, `author`, `book`) VALUES
(1, 'hasan', 'my book'),
(2, 'hasan', 'my book'),
(3, ' হুমায়ূন আহমেদ', 'ময়ূরাক্ষী'),
(1, ' হুমায়ূন আহমেদ', 'ময়ূরাক্ষী'),
(2, ' হুমায়ূন আহমেদ', 'ময়ূরাক্ষী'),
(1, 'হুমাযূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম'),
(1, 'হুমাযূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম'),
(1, 'হুমাযূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম'),
(1, 'হুমাযূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম'),
(1, 'ৌ', 'ৌ'),
(1, 'হুমাযূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম'),
(2, 'হুমাযূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম'),
(2, 'হুমায়ূন আহমেদ', 'হিমুর হাতে কয়েকটি নীলপদ্ম'),
(2, ' হুমায়ূন আহমেদ', 'ময়ূরাক্ষী');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `email` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `wpm` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wpm`
--

CREATE TABLE `wpm` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `content` varchar(100) NOT NULL,
  `wpm` double(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wpm`
--

INSERT INTO `wpm` (`id`, `email`, `content`, `wpm`) VALUES
(1, 'mah@gmail.com', 'হিমুর হাতে কয়েকটি নীলপদ্ম', 24.00),
(2, 'nag@gmail.com', 'হিমুর হাতে কয়েকটি নীলপদ্ম', 26.00),
(3, 'sakib@gmail.com', 'ময়ূরাক্ষী', 30.00),
(4, 'mah@gmail.com', 'হিমুর মধ্যদুপুর', 29.00),
(5, 'mayaz@gmail.com', 'দরজার ওপাশে', 26.00),
(6, 'mhasan.csedu@gmail.com', 'ময়ূরাক্ষী', 35.00),
(7, 'bangla71@gmail.com', 'বাংলা', 21.00);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
