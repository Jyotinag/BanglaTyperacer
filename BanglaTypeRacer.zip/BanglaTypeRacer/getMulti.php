
<?php
$q = $_GET['q'];

$db='banglatype';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");



$sql="SELECT * FROM multiplayer WHERE host = $q";
$result = mysqli_query($db_connect,$sql);
$countId = mysqli_num_rows($result);
if ($countId > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		echo "HOST WPM: " .$row["hostwpm"]. "<br>";
		echo "GUEST WPM: " .$row["guestwpm"]. "<br>";
		
    }
}


mysqli_close($db_connect);
?>

</body>
</html>