<?php
session_start();
$db='testbangla';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");

//////

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL

$mail = $_POST['email'];
$password = $_POST['password'];
//$address = $_POST['address'];
//if($password !='' && $email !=''){
//Insert Query of SQL
print $mail;

$sql="SELECT * FROM login WHERE email = '$mail' AND password='$password'";

$result = mysqli_query($db_connect,$sql);
$row = mysqli_fetch_assoc($result);
$id = $row['email'];


$countId = mysqli_num_rows($result);
print $countId;


if ($countId > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		echo "Email: " .$row["email"]. "<br>";
		echo "Password: " .$row["password"]. "<br>";
		
    }
}
if($countId){
	echo "<br/><br/><span>Login successfully...!!</span>";
}
else{
	echo "<br/><br/><span>Login not complete...!!</span>";
}
//$query = mysqli_query($db_connect,"insert into login(email, password) values ('$email', '$password')");


//}
//else{
//echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
//}
}

mysqli_close($db_connect);
//CloseCon($conn);
//mysqli_close($connection); // Closing Connection with Server
?>