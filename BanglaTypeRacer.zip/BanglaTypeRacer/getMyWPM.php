
<?php

session_start();
$p = $_SESSION['username'];

//$q = $_GET['q'];

$db='banglatype';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");



//mysqli_select_db($con,"ajax_demo");
$sql="SELECT * FROM wpm WHERE email = '$p' ORDER BY id DESC LIMIT 3";
$result = mysqli_query($db_connect,$sql);
$countId = mysqli_num_rows($result);
$countCheck = 1;
if ($countId > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($countCheck == 4){
			break;
		}
		echo "Serial: "; echo  $countCheck++;  echo "<br>";
		echo "Source: " .$row["content"]. "<br>";
		echo "WPM: " .$row["wpm"]. "<br><br>";
       
    }
}
mysqli_close($db_connect);
?>