<?php



$db='testbangla';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");

//////
$idNo = 1;
//$sql = "SELECT * FROM content where id = 1";
$sql = "SELECT * FROM content where id = $idNo";
$resultId  = mysqli_query($db_connect,$sql);
//printf(" Number of rows -> %d\n",$resultId);
//echo $resultId;

if ($resultId->num_rows > 0) {
    // output data of each row
    while($row = $resultId->fetch_assoc()) {
        echo "id: " .$row["id"]. "<br>";
		echo "Author: " .$row["author"]. "<br>";
		echo "Content: " .$row["content"]. "<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($db_connect);
//CloseCon($conn);
//mysqli_close($connection); // Closing Connection with Server
?>