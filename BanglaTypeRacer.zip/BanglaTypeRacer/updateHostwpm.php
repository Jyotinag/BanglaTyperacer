<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
$q = $_GET['q'];
$r = $_GET['r'];

$db='banglatype';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");



$sql = "UPDATE multiplayer SET hostWPM=$q WHERE host = $r";
$result = mysqli_query($db_connect,$sql);

	
	
	echo "hey host. your wpm is updated.";
	
	
mysqli_close($db_connect);
?>





</body>
</html>