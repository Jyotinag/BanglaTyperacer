<!DOCTYPE html>
<html>
<head>
<title>LOGIN</title>
<link href="insert.css" rel="stylesheet">
</head>
<body>
<div class="maindiv">
<!--HTML Form -->
<div class="form_div">
<div class="title">
<h2>PASSAGE INSERT</h2>
</div>
<form action="insertPassage.php" method="post" accept-charset="utf-8">
<!-- Method can be set as POST for hiding values in URL-->
<h2>Form</h2>
<label>Name of the Author:</label>
<input class="input" name="author" type="text" value="">
<label>Name of the Source:</label>
<input class="input" name="book" type="text" value="">
<label>Passage:</label>
<input class="input" name="content" type="text" value="">
<label>About:</label>
<input class="input" name="about" type="text" value="">

<input class="submit" name="submit" type="submit" value="Submit">
</form>
</div>
</div>
</body>
</html>