<?php

$db='testbangla';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");

//////

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL

$author = $_POST['author'];
$book = $_POST['book'];
$content = $_POST['content'];
$about = $_POST['about'];
if($author !='' && $book !='' && $content !=''){
//Insert Query of SQL
$sql = "SELECT id FROM content";
$resultId  = mysqli_query($db_connect,$sql);
$countId = mysqli_num_rows($resultId);
printf(" Number of rows -> %d\n",$countId);
$countId = $countId + 1;
$query = mysqli_query($db_connect,"insert into source(id, author, book) values ('$countId', '$author', '$book')");
$query = mysqli_query($db_connect,"insert into passage(id, content) values ('$countId', '$content')");
$query = mysqli_query($db_connect,"insert into content(id, author, book, content, about) values ('$countId', '$author', '$book', '$content', '$about')");

echo "<br/><br/><span>Login successfully...!!</span>";
}
else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}
}

mysqli_close($db_connect);
//CloseCon($conn);
//mysqli_close($connection); // Closing Connection with Server
?>