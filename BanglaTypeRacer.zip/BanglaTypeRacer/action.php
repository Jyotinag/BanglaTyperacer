<?php include 'dbConfig.php'; ?>
<?php
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $password_hash = password_hash($password,PASSWORD_DEFAULT,array('cost'=>10));
    
    $sql = "INSERT INTO user(first_name,last_name,email,password) VALUES(?,?,?,?)";
    $loginsql = "INSERT INTO login(email,password) VALUES(?,?)";
    $stmt = $mysqli->prepare($sql);
    $stmt1 = $mysqli->prepare($loginsql);
    $stmt->bind_param('ssss',$first_name,$last_name,$email,$password_hash);
    $stmt1->bind_param('ss',$email,$password_hash);
    
    $stmt->execute();
    $stmt1->execute();
    $stmt->close();
    $stmt1->close();
    
    $mysqli->close();
?>