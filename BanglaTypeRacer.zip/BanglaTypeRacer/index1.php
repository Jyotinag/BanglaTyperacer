<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>
  <div class="header">
    <h1>BANGLA TYPE RACER</h1>
    <h2 id="typeShow"></h2>
    <script>
      var i = 0;
      var txt = 'বাংলা টাইপিং গেম  : মজার খেলায় বাংলা শিখি';
      var spd = 350;
      var x = typeWriter();

      function typeWriter() {
        if (i < txt.length) {
          document.getElementById("typeShow").innerHTML += txt.charAt(i);
          i++;
          setTimeout(typeWriter, spd);
        }
      }

    </script>
  </div>

  <div class="topnav">
    <a href="index.php"><button style="width:auto;">Register</button></a>
    <a href="login.php"><button style="width:auto;">Login</button></a>
    <a href="tutorial.php" target="_blank"><button style="width:auto;">Tutorial</button></a>
  </div>
  <div class="row">
    <div class="leftcolumn">
      <div class="card">






        <div class="slideshow-container" style="height:200px;">


          <img src="banglaType.jpg" alt="Mountain View" width="100%" height="100%">



        </div>

        <br><br><br>
      </div>
      <div class="card">

        <a href="layout.php"><button style="width:990px; height: 100px; font-size: 50px; ">Race as Guest</button></a>
      </div>
      <div class="card">
        <h3>Bangla keyboards layouts...</h3>
        <div class="slideshow-container" style="height:350px;">

          <div class="slideshow-container">

            <div class="mySlides fade">
              <div class="numbertext">1 / 3</div>
              <img src="Avro.png" style="width:100%">
              <div class="text">Avro_Phonetic_Keyboard_Layout</div>
            </div>

            <div class="mySlides fade">
              <div class="numbertext">2 / 3</div>
              <img src="Bijoy.png" style="width:100%">
              <div class="text">Bijoy_Bayanno_Keyboard_Layout</div>
            </div>

            <div class="mySlides fade">
              <div class="numbertext">3 / 3</div>
              <img src="Bangladesh_National_Keyboard_Layout.png" style="width:100%">
              <div class="text">Bangladesh_National_Keyboard_Layout</div>
            </div>

          </div>
          <br>

          <div style="text-align:center">
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
          </div>

          <script>
            var slideIndex = 0;
            showSlides();

            function showSlides() {
              var i;
              var slides = document.getElementsByClassName("mySlides");
              var dots = document.getElementsByClassName("dot");
              for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
              }
              slideIndex++;
              if (slideIndex > slides.length) {
                slideIndex = 1
              }
              for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
              }
              slides[slideIndex - 1].style.display = "block";
              dots[slideIndex - 1].className += " active";
              setTimeout(showSlides, 2000); // Change image every 2 seconds
            }

          </script>



        </div>
      </div>
    </div>
    <script>
      function showWPM() {


        if (window.XMLHttpRequest) {
          // code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp = new XMLHttpRequest();
        } else {
          // code for IE6, IE5
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            //document.getElementById("txtHint").innerHTML = this.responseText;
            var rspncWPM = this.responseText;
            // Passage Finding
            //var posStart = rspnc.indexOf("Content");
            //posStart = posStart+9;
            //var posEnd = rspnc.indexOf("About");
            //posEnd = posEnd-5;

            // Passage Content
            //var text = "";
            //var i;
            //for (i = posStart; i <= posEnd; i++) {
            //	text += rspnc[i];
            //}
            document.getElementById("demoWPM").innerHTML = rspncWPM;
          }
        };

        xmlhttp.open("GET", "getWPM.php", true);
        xmlhttp.send();

      }

      function removeWPM() {

        if (window.XMLHttpRequest) {
          // code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp = new XMLHttpRequest();
        } else {
          // code for IE6, IE5
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            var rspncWPM = this.responseText;
            rspncWPM = ""
            document.getElementById("demoWPM").innerHTML = rspncWPM;
          }
        };

        xmlhttp.open("GET", "getWPM.php", true);
        xmlhttp.send();

      }




      function showRecentWPM() {


        if (window.XMLHttpRequest) {
          // code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp = new XMLHttpRequest();
        } else {
          // code for IE6, IE5
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            var rspncWPM = this.responseText;

            document.getElementById("recentWPM").innerHTML = rspncWPM;
          }
        };

        xmlhttp.open("GET", "getRecentWPM.php", true);
        xmlhttp.send();

      }

      function removeRecentWPM() {

        if (window.XMLHttpRequest) {
          // code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp = new XMLHttpRequest();
        } else {
          // code for IE6, IE5
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            var rspncWPM = this.responseText;
            rspncWPM = ""
            document.getElementById("recentWPM").innerHTML = rspncWPM;
          }
        };

        xmlhttp.open("GET", "getWPM.php", true);
        xmlhttp.send();

      }

    </script>
    <div class="rightcolumn">
      <div class="card">
        <h3> TYPING IN BANGLA : TIPS AND TRICKS </h3>
        <iframe width="280" height="220" src="https://www.youtube.com/embed/je9_myKYAeY"></iframe>
      </div>
      <div class="topnav">
        <font color="red">
          <h3>Top Users</h3>
        </font>





        <button onclick="document.getElementById('demoWPM').innerHTML = showWPM()" style="width:auto;">Show</button>
        <button onclick="document.getElementById('demoWPM').innerHTML = removeWPM()" style="width:auto;">Hide</button>
        <button onclick="document.getElementById('demoWPM').innerHTML = showWPM()" style="width:auto;">Refresh</button>
        <font color="blue">
          <p id="demoWPM"></p>
        </font>

      </div><br>
      <div class="topnav">
        <font color="red">
          <h3>Recent Users</h3>
        </font>





        <button onclick="document.getElementById('recentWPM').innerHTML = showRecentWPM()" style="width:auto;">Show</button>
        <button onclick="document.getElementById('recentWPM').innerHTML = removeRecentWPM()" style="width:auto;">Hide</button>
        <button onclick="document.getElementById('recentWPM').innerHTML = showRecentWPM()" style="width:auto;">Refresh</button>
        <font color="blue">
          <p id="recentWPM"></p>
        </font>

      </div>
    </div>
  </div>
</body>

</html>
