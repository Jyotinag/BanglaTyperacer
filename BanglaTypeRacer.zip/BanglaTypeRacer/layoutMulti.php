<?php
// Start the session
session_start();

$_SESSION["userEmail"] = "not found";
$_SESSION["userPassword"] = "not found";
//echo $_SESSION['userEmail'];
?>



<!DOCTYPE html>




<html>
<head>
<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>





<div class="header">
  <h1>BANGLA TYPE RACER</h1>
  <h2 id="typeShow"></h2>
  

<script>

var i = 0;
var txt = 'বাংলা টাইপিং গেম  : মজার খেলায় বাংলা শিখি';
var spd = 350;
var x = typeWriter();
function typeWriter() {
  if (i < txt.length) {
    document.getElementById("typeShow").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, spd);
  }
}


</script>
</div>

<div class="topnav">
			<a href="index1.php"><button style="width:auto;">Home</button></a>
			<a href="index.php"><button style="width:auto;">Register</button></a>
			<a href="login.php"><button style="width:auto;">Login</button></a>
			<a href="tutorial.php" target="_blank"><button style="width:auto;">Tutorial</button></a>
		</div>



<div class="row">
  <div class="leftcolumn">
    <div class="card">
	  
	 
<img src="banglaType.jpg" alt="Mountain View" width="850" height="250">


	 
	  
      <br><br>


<div style="margin-left:15px; width:200px; margin-top:7px;">
<button onclick="one()">Multi </button><br><br>
<a href="layout.php"><button style="width:auto;">Back</button></a>
</div>



<div id="entire" style="margin-left:490px; margin-top:-22px; width:400px; height:200px;"><div id="a"></div><div id="b"></div><div id="c"></div></div>

                        <button onclick="mySleep()">START</button>

                        <br>
                        <div id="txtHint"><b></b></div>

                        <br><br>
                        <div id="txtHintChk" class=a><b></b></div>

                        <br>


                        <p>
                            <font size="5" color="blue"> Total time <span id="countdowntimer">0 </span> Seconds</font>
                        </p>



                        Enter your Content: <input type="text" id="fname"  onkeyup="myFunction()">

                        <p>
                            <font size="5">Content is: <span id="myText"></span></font>
                        </p>

                        <br>
                        <p>
                            <font size="5" color="blue"> YOUR TYPING SPEED IS <span id="typeSpeed">0 </span> character per Seconds</font>
                        </p>
                        <br>





                        <script>
var text = "";
var tim = 0;
var checkTimer = 0;
var checkTimerNew = 0;
var timeleft = 0;
var timeleftNew = 0;
var downloadTimer;
var downloadTimerNew;
var speed = 0;
var speedTimer;
var wpmspeed = 0;
var mywpmspeed = 0;
var checkmywpm = 0;
var textLength;
var wrongTextLength;
var IamHost = 0;
var IamGuest = 0;
var updateHostWPM = 0;
var updateGuestWPM = 0;
var HOSTID = "";
var HOST = 0;
function showHost(str) {
	
	text = "";
		IamHost = 1;
		checkTimer = 1;
		
		timeleft = 0;
		clearInterval(downloadTimer);
		document.getElementById("countdowntimer").textContent = timeleft;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
				var rspnc = this.responseText;
				// Passage Finding
				var posStart = rspnc.indexOf("Content");
				posStart = posStart+9;
				var posEnd = rspnc.indexOf("About");
				posEnd = posEnd-5;
				
				// Passage Content
				//var text = "";
				var i;
				for (i = posStart; i <= posEnd; i++) {
					text += rspnc[i];
				}
				
				
				
				textLength = text.length;
				document.getElementById("txtHintChk").innerHTML = text;
				document.getElementById("fname").value = "";
				document.getElementById("myText").innerHTML = "";
				document.getElementById("typeSpeed").textContent = 0;
				
				// HOSTID Finding
				var hostStart = rspnc.indexOf("Host");
				hostStart = hostStart+10;
				var hostEnd = rspnc.indexOf("Author");
				hostEnd = hostEnd-5;
				
				var ii;
				for (ii = hostStart; ii <= hostEnd; ii++) {
					HOSTID += rspnc[ii];
				}
				HOST = parseInt(HOSTID);
				//document.getElementById("a").innerHTML = HOSTID;
				
				
				// TIMER SET NEW
	
	
			
            }
			
        };
		
        xmlhttp.open("GET","getHostID.php?q="+str,true);
        xmlhttp.send();
    
	
	
}


function showMulti(strM) {
	

        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("b").innerHTML = this.responseText;

            }
			
        };
		
        xmlhttp.open("GET","getMulti.php?q="+strM,true);
        xmlhttp.send();	
}

function checkHostID(multiStr) {
	
	text = "";
		IamGuest = 1;
		checkTimer = 1;
		timeleft = 0;
		clearInterval(downloadTimer);
		document.getElementById("countdowntimer").textContent = timeleft;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
				var rspnc = this.responseText;
				// Passage Finding
				var posStart = rspnc.indexOf("Content");
				posStart = posStart+9;
				var posEnd = rspnc.indexOf("About");
				posEnd = posEnd-5;
				
				// Passage Content
				//var text = "";
				var i;
				for (i = posStart; i <= posEnd; i++) {
					text += rspnc[i];
				}
				textLength = text.length;
				document.getElementById("txtHintChk").innerHTML = text;
				document.getElementById("fname").value = "";
				document.getElementById("myText").innerHTML = "";
				document.getElementById("typeSpeed").textContent = 0;
				
				
				// HOSTID Finding
				var hostStart = rspnc.indexOf("Host");
				hostStart = hostStart+10;
				var hostEnd = rspnc.indexOf("Author");
				hostEnd = hostEnd-5;
				
				var ii;
				for (ii = hostStart; ii <= hostEnd; ii++) {
					HOSTID += rspnc[ii];
				}
				HOST = parseInt(HOSTID);
            }
        };
		
        xmlhttp.open("GET","checkHostID.php?q="+multiStr,true);
        xmlhttp.send();		
    
}

function myFunction() {
	tim = tim+1;
    var x = document.getElementById("fname").value;
	
	var len = x.length;
	var writeTextOK = "";
	var writeTextNotOK = "";
	var writeText = "";
	var ii;
	var chk = 0;
	for (ii = 0; ii <len; ii++) {
		if(text[ii]!=x[ii]){
			chk = 1;
		}
		if(chk == 0){
			writeTextOK +=x[ii];
		}
		else{
			writeTextNotOK +=x[ii];
		}
	}
	speed = writeTextOK.length;
	wrongTextLength = writeTextNotOK.length;
	
	writeTextNotOK = writeTextNotOK.fontcolor("red");
	writeTextOK = writeTextOK.fontcolor("green");
	writeText = writeTextOK.concat(writeTextNotOK);
    document.getElementById("myText").innerHTML = writeText;
	

			if((speed == textLength) && (wrongTextLength == 0)){
				
			clearInterval(downloadTimer);
			
			if(IamHost == 1){
				IamHost   = 0;
				updateHostMulti(wpmspeed);
				}
				
				if(IamGuest == 1){
					IamGuest   = 0;
				updateGuestMulti(wpmspeed);
				}
				
				document.getElementById("fname").disabled = true;
									
                                    // SAVE WPM to DATABASE
									//saveToDB(wpmspeed);
			}
		
	// TIMER SET
	
	if( checkTimer >0){
	checkTimer =0
	checkTimerNew = 1;
			downloadTimer = setInterval(function(){
		timeleft++;
		document.getElementById("countdowntimer").textContent = timeleft;
		// TYPING SPEED
		 wpmspeed = speed/timeleft;
		document.getElementById("typeSpeed").textContent = speed/timeleft;
		//mywpmspeed = wpmspeed;
		if(mywpmspeed < wpmspeed){
		
		mywpmspeed = wpmspeed;
		//document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed; 
	}
		document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed;
		//if(timeleft >= 40)
		if( timeleft >= 30)
			clearInterval(downloadTimer);
			//updateHostWPM = 1;
			//updateHostMulti(wpmspeed);
		},1000);
		
		//document.getElementById("b").innerHTML = wpmspeed; 
	}
	
	
	
	
	//if(checkmywpm == 1){
		
		//document.getElementById("myWPM").innerHTML = mywpm + wpmspeed; 
	//}
	//document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed;
	
}


function updateHostMulti(hostWPM){
	
	if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("c").innerHTML = this.responseText;
				var rspnc = this.responseText;
				
            }
        };
		
        xmlhttp.open("GET","updateHostwpm.php?q="+hostWPM + "&r=" + HOST,true);
        xmlhttp.send();
}

function updateGuestMulti(guestWPM){
	
	if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("c").innerHTML = this.responseText;
				var rspnc = this.responseText;
				
            }
        };
		
        xmlhttp.open("GET","updateGuestWpm.php?q="+guestWPM + "&r=" + HOST,true);
        xmlhttp.send();
}
	   
function showWPM() {
	
	
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //document.getElementById("txtHint").innerHTML = this.responseText;
				var rspncWPM = this.responseText;
				// Passage Finding
				//var posStart = rspnc.indexOf("Content");
				//posStart = posStart+9;
				//var posEnd = rspnc.indexOf("About");
				//posEnd = posEnd-5;
				
				// Passage Content
				//var text = "";
				//var i;
				//for (i = posStart; i <= posEnd; i++) {
				//	text += rspnc[i];
				//}
				document.getElementById("demoWPM").innerHTML = rspncWPM;
            }
        };
		
        xmlhttp.open("GET","getWPM.php",true);
        xmlhttp.send();
    
}

function removeWPM() {
	
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				var rspncWPM = this.responseText;
				rspncWPM = ""
				document.getElementById("demoWPM").innerHTML = rspncWPM;
            }
        };
		
        xmlhttp.open("GET","getWPM.php",true);
        xmlhttp.send();
    
}
    
	

	
function showRecentWPM() {
	
	
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				var rspncWPM = this.responseText;
				
				document.getElementById("recentWPM").innerHTML = rspncWPM;
            }
        };
		
        xmlhttp.open("GET","getRecentWPM.php",true);
        xmlhttp.send();
    
}

function removeRecentWPM() {
	
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				var rspncWPM = this.responseText;
				rspncWPM = ""
				document.getElementById("recentWPM").innerHTML = rspncWPM;
            }
        };
		
        xmlhttp.open("GET","getWPM.php",true);
        xmlhttp.send();
    
}


function one()
{
	var d="";
	document.getElementById("txtHint").innerHTML = "";
	document.getElementById("b").innerHTML = d;
document.getElementById("c").innerHTML = "";
document.getElementById("txtHintChk").innerHTML = "";
				document.getElementById("fname").value = "";
				document.getElementById("myText").innerHTML = "";
				document.getElementById("typeSpeed").textContent = 0;
				
		timeleft = 0;
		clearInterval(downloadTimer);
		document.getElementById("countdowntimer").textContent = timeleft;
	document.getElementById("fname").disabled = true;
	var newButtonHost = '<button onclick="two()">Host</button>';
	var newButtonGuest = '<button onclick="three()">Guest</button>';
document.getElementById("a").innerHTML="Select your side."+newButtonHost+newButtonGuest;

}

function two()
{
document.getElementById("a").innerHTML="You are host.";
//var newButtonStart = '<button onclick="setTimeout(mySleep, 3000);">Start</button>';
var multiPassageID = Math.floor((Math.random() * 10) + 1);;
showHost(multiPassageID);
//showHostID(multiPassageID);

//sleep(50000);
//document.getElementById("b").innerHTML="You are host ."+HOST;
//document.getElementById("b").innerHTML = HOSTID;
//startRace(HOST);


}
function three()
{
document.getElementById("a").innerHTML="You are guest.";
document.getElementById("b").innerHTML = "";
showGuestID();	
document.getElementById("fname").disabled = true;
}

function showGuestID() {
    var guestID = prompt("Please enter host id", "");
    if (guestID != null) {
        document.getElementById("b").innerHTML =
        "Host id : " + guestID ;
		
		checkHostID(guestID);
    }
}
function mySleep() {
    document.getElementById("fname").disabled = false;
	timeleftNew =0;
	
			downloadTimerNew = setInterval(function(){
		timeleftNew++;
		//document.getElementById("a").textContent = timeleft;
			if(timeleftNew >= 30){
				
			clearInterval(downloadTimer);
			document.getElementById("fname").disabled = true;
			
			if(timeleftNew >= 40){
			if(IamHost == 1){
				IamHost   = 0;
				updateHostMulti(wpmspeed);
				}
				
				if(IamGuest == 1){
					IamGuest   = 0;
				updateGuestMulti(wpmspeed);
				}
			showMulti(HOST);
			
				}
			}
			//updateHostWPM = 1;
			//updateHostMulti(wpmspeed);
		},1000);
		
		//document.getElementById("b").innerHTML = wpmspeed; 
	
}

</script>
	
	</div>
    
  </div>
  <div class="rightcolumn">
    <div class="card">
	    <img src="login.png" alt="Mountain View" width="100" height="100">

					<h3 id="myWPM">
					</h3>
					<h3 id="myNamee">
					</h3>


					<script>
						var mywpm = "Best WPM : ";
						var mywpmspeed = 0;
						document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed;
						document.getElementById("myNamee").innerHTML = mywpm + $_SESSION['userEmail'];

					</script>
    </div>
	<br>
    <div class="topnav">
      <font color="red"><h3>Top Users</h3></font>
	  
	  


	  
      <button onclick="document.getElementById('demoWPM').innerHTML = showWPM()" style="width:auto;">Show</button>
	  <button onclick="document.getElementById('demoWPM').innerHTML = removeWPM()" style="width:auto;">Hide</button>
	  <button onclick="document.getElementById('demoWPM').innerHTML = showWPM()" style="width:auto;">Refresh</button>
	  <font color="blue"><p id="demoWPM"></p></font>
	
    </div><br>
	<div class="topnav">
      <font color="red"><h3>Recent Users</h3></font>
	  
	  


	  
      <button onclick="document.getElementById('recentWPM').innerHTML = showRecentWPM()" style="width:auto;">Show</button>
	  <button onclick="document.getElementById('recentWPM').innerHTML = removeRecentWPM()" style="width:auto;">Hide</button>
	  <button onclick="document.getElementById('recentWPM').innerHTML = showRecentWPM()" style="width:auto;">Refresh</button>
	  <font color="blue"><p id="recentWPM"></p></font>
	
    </div>
    <div class="card">
	  <iframe style="height: 650px; 
    width: 290px;
    background-color: powderblue" src="formpage.html" name="targetframe"  frameborder="0" >
    </iframe>
    </div>
  </div>
</div>

</body>
</html>
