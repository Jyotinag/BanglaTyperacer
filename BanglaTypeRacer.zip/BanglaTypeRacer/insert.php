<?php

//include 'db_connection.php';
//include 'db_query.php';
//$conn = OpenCon();
//mysqli_query($conn,'SET CHARACTER SET utf8'); 
//mysqli_query($conn,"SET SESSION collation_connection ='utf8_general_ci'");
//$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
//$db = mysql_select_db("bangla", $connection); // Selecting Database from Server

//$setBangla = DoQuery('SET character_set utf8');

//$setBangla = DoQuery("SET SESSION collation_connection ='utf8_general_ci'");

//////
$db='testbangla';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");

//////

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
//$address = $_POST['address'];
if($name !='' && $email !=''){
//Insert Query of SQL
$query = mysqli_query($db_connect,"insert into register(name, email, password) values ('$name', '$email', '$password')");

//$query = DoQuery("insert into information(name, email, contact) values ('$name', '$email', '$contact')");
echo $query;


echo "<br/><br/><span>Data Inserted successfully...!!</span>";
}
else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}
}

mysqli_close($db_connect);
//CloseCon($conn);
//mysqli_close($connection); // Closing Connection with Server
?>