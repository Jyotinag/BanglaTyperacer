
<?php

session_start();
$p = $_SESSION['username'];

$q = $_GET['q'];
$rr = $_GET['r'];

$db='banglatype';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");


$sql = "SELECT id FROM wpm";
$resultId  = mysqli_query($db_connect,$sql);
$countId = mysqli_num_rows($resultId);
$countId = $countId + 1;


$sql="INSERT INTO wpm(id, email, content, wpm) values ('$countId', '$p', '$rr', '$q')";
$result = mysqli_query($db_connect,$sql);

echo "Updated";

mysqli_close($db_connect);
?>