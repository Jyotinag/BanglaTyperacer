<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
$q = $_GET['q'];

$db='banglatype';//mysql database
$dbuser='root';//mysql username
$dbpass='';//mysql password
$db_connect = new mysqli('localhost',$dbuser,$dbpass,$db) or die('Opps');
//mysqli_select_db($db,$db_connect);
mysqli_query($db_connect,'SET CHARACTER SET utf8');
mysqli_query($db_connect,"SET SESSION collation_connection ='utf8_general_ci'");



//mysqli_select_db($con,"ajax_demo");

//$sql="SELECT * FROM wpm";
//$result = mysqli_query($db_connect,$sql);
//$countId = mysqli_num_rows($result);

$sql="SELECT passageID FROM multiplayer where host = $q";
	$result = mysqli_query($db_connect,$sql);
	$countId = mysqli_num_rows($result);

	$passID;
	
	if ($countId > 0)
	{
while($row = $result->fetch_assoc()) {
		$passID = $row["passageID"];
		//echo $row["passageID"];
    }
$sql = "UPDATE multiplayer SET guest=$q WHERE host = $q";
$result = mysqli_query($db_connect,$sql);

	}

echo "Host id = $q<br>";

	$sql="SELECT * FROM content WHERE id = $passID";
$result = mysqli_query($db_connect,$sql);
$countId = mysqli_num_rows($result);
if ($countId > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		echo "Author: " .$row["author"]. "<br>";
		echo "Book: " .$row["book"]. "<br>";
		echo "Content: " .$row["content"]. "<br>";
		echo "About: " .$row["about"]. "<br>";
    }
}
	
	
mysqli_close($db_connect);
?>





</body>
</html>