<?php
// Start the session
session_start();

$_SESSION["userEmail"] = "not found";
$_SESSION["userPassword"] = "not found";
//echo $_SESSION['userEmail'];
?>



<!DOCTYPE html>




<html>
<head>
<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>





<div class="header">
  <h1>BANGLA TYPE RACER</h1>
  <h2 id="typeShow"></h2>
  

<script>

var i = 0;
var txt = 'বাংলা টাইপিং গেম  : মজার খেলায় বাংলা শিখি';
var spd = 350;
var x = typeWriter();
function typeWriter() {
  if (i < txt.length) {
    document.getElementById("typeShow").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, spd);
  }
}


</script>
</div>

<div class="topnav">
  <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Register</button>
  <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>
  <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">TUTORIAL</button>
  <button onclick="myAFunction()" style="width:auto;">Profile</button>
  <script>
function myAFunction(str) {
    window.open("http://localhost/REGISTER/profile.php");
}
</script>
</div>




<div class="row">
  <div class="leftcolumn">
    <div class="card">
	  
	 



	  
      <div class="slideshow-container" style="height:200px;">
	  

<img src="banglaType.jpg" alt="Mountain View" width="850" height="250">
	  
	  
	  
	  </div>
	  


	
	</div>
    <div class="card">
      <h1>TUTORIAL</h1>
      <h3>Bangla keyboards layouts...</h3>
      <div class="slideshow-container" style="height:350px;">
		
		<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="Avro.png" style="width:100%">
  <div class="text">Avro_Phonetic_Keyboard_Layout</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="Bijoy.png" style="width:100%">
  <div class="text">Bijoy_Bayanno_Keyboard_Layout</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="Bangladesh_National_Keyboard_Layout.png" style="width:100%">
  <div class="text">Bangladesh_National_Keyboard_Layout</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
		
		

	  </div>
      </div>
  </div>

</div>


<script>


</script>

<div class="footer">
  <h2>Footer</h2>
  <p id="demoWPMa"></p>
	  
	  <script>
  document.getElementById("demoWPM").innerHTML = showWPM();
  </script>
</div>

</body>
</html>
