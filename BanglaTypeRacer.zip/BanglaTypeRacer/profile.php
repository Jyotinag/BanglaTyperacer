<?php
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/custom.css" />
        <meta charset="UTF-8">
        <title>Welcome</title>
    </head>

    <body>
        <div class="header">
            <h1>BANGLA TYPE RACER</h1>
            <h2 id="typeShow"></h2>


            <script>
                var i = 0;
                var txt = 'বাংলা টাইপিং গেম  : মজার খেলায় বাংলা শিখি';
                var spd = 350;
                var x = typeWriter();

                function typeWriter() {
                    if (i < txt.length) {
                        document.getElementById("typeShow").innerHTML += txt.charAt(i);
                        i++;
                        setTimeout(typeWriter, spd);
                    }
                }

            </script>
        </div>

        <div class="topnav">
            <a href="index1.php"><button style="width:auto;">Home</button></a>
            <a href="tutorial.php" target="_blank"><button style="width:auto;">Tutorial</button></a>

            <a href="logout.php"><button style="width:auto; float: right;" class = "btn btn-danger">Sign Out</button></a>
        </div>

        <div class="row">
            <div class="leftcolumn">
                <div class="card">

                    <div>



                        <img src="banglaType.jpg" alt="Mountain View" width="850" height="250">




                        <br><br>
						
						<a href="profileMulti.php"><button style="width:auto;">RACE TWO PLAYER</button></a>
                        <br>
				
                        <button onclick="myFun()">RACE</button>


                        <script>

                            function myFun() {
								var numPass = Math.floor((Math.random() * 10) + 1);
                                showUser(numPass);
                            }

                        </script>


                        <br>
                        <div id="txtHint"><b>Information will be here...</b></div>

                        <br><br>
                        <div id="txtHintChk" class=a><b></b></div>

                        <br>


                        <p>
                            <font size="5" color="blue"> Total time <span id="countdowntimer">0 </span> Seconds</font>
                        </p>



                        Enter your Content: <input type="text" id="fname"  onkeyup="myFunction()">

                        <p>
                            <font size="5">Content is: <span id="myText"></span></font>
                        </p>

                        <br>
                        <p>
                            <font size="5" color="blue"> YOUR TYPING SPEED IS <span id="typeSpeed">0 </span> character per Seconds</font>
                        </p>
                        <br>





                        <script>
                            var text = "";
                            var tim = 0;
                            var checkTimer = 0;
                            var timeleft = 0;
                            var downloadTimer;
                            var speed = 0;
                            var speedTimer;
                            var wpmspeed = 0;
                            var mywpmspeed = 0;
                            var checkmywpm = 0;
                            var textLength;
                            var wrongTextLength;
                            var source = "";

                            function showUser(str) {
								source = "";
								//document.getElementById("myData").innerHTML = "hi";
								document.getElementById("fname").disabled = false;

                                text = "";
                                if (str == "") {
                                    checkTimer = 0;
                                    tim = 0;
                                    timeleft = 0;
                                    document.getElementById("txtHint").innerHTML = "";
                                    document.getElementById("txtHintChk").innerHTML = "";
                                    document.getElementById("myText").innerHTML = "";
                                    document.getElementById("fname").value = "";
                                    clearInterval(downloadTimer);
                                    document.getElementById("countdowntimer").textContent = timeleft;
                                    return;
                                } else {
                                    checkTimer = 1;
                                    timeleft = 0;
                                    clearInterval(downloadTimer);
                                    document.getElementById("countdowntimer").textContent = timeleft;
                                    if (window.XMLHttpRequest) {
                                        // code for IE7+, Firefox, Chrome, Opera, Safari
                                        xmlhttp = new XMLHttpRequest();
                                    } else {
                                        // code for IE6, IE5
                                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                    }
                                    xmlhttp.onreadystatechange = function() {
                                        if (this.readyState == 4 && this.status == 200) {
                                            document.getElementById("txtHint").innerHTML = this.responseText;
                                            var rspnc = this.responseText;
                                            // Passage Finding
                                            var posStart = rspnc.indexOf("Content");
                                            posStart = posStart + 9;
                                            var posEnd = rspnc.indexOf("About");
                                            posEnd = posEnd - 5;

                                            // Passage Content
                                            //var text = "";
                                            var i;
                                            for (i = posStart; i <= posEnd; i++) {
                                                text += rspnc[i];
                                            }
                                            var posBook = rspnc.indexOf("Book");
                                            posBook = posBook + 6;
                                            var posSource = rspnc.indexOf("Content");
                                            posSource = posSource - 5;

                                            // Passage Content
                                            //var text = "";
                                            var l;
                                            for (l = posBook; l <= posSource; l++) {
                                                source += rspnc[l];
                                            }
                                            //document.write(source);
                                            //document.getElementById("txtHintChk").innerHTML = source;
                                            textLength = text.length;
                                            document.getElementById("txtHintChk").innerHTML = text;
                                            document.getElementById("fname").value = "";
                                            document.getElementById("myText").innerHTML = "";
                                            document.getElementById("typeSpeed").textContent = 0;
                                        }
                                    };

                                    xmlhttp.open("GET", "raceTestTwoGetPassage.php?q=" + str, true);
                                    xmlhttp.send();
                                }
                            }

                            function myFunction() {
                                tim = tim + 1;
								document.getElementById("fname").disabled = false;
                                var x = document.getElementById("fname").value;

                                var len = x.length;
                                var writeTextOK = "";
                                var writeTextNotOK = "";
                                var writeText = "";
                                var ii;
                                var chk = 0;
                                for (ii = 0; ii < len; ii++) {
                                    if (text[ii] != x[ii]) {
                                        chk = 1;
                                    }
                                    if (chk == 0) {
                                        writeTextOK += x[ii];
                                    } else {
                                        writeTextNotOK += x[ii];
                                    }
                                }
                                speed = writeTextOK.length;
                                wrongTextLength = writeTextNotOK.length;

                                writeTextNotOK = writeTextNotOK.fontcolor("red");
                                writeTextOK = writeTextOK.fontcolor("green");
                                writeText = writeTextOK.concat(writeTextNotOK);
                                document.getElementById("myText").innerHTML = writeText;


                                if ((speed == textLength) && (wrongTextLength == 0)) {
                                    clearInterval(downloadTimer);
									
									// DISABLE TEXT INPUT
									document.getElementById("fname").disabled = true;
									
                                    // SAVE WPM to DATABASE
									saveToDB(wpmspeed);
									
                                }


                                // TIMER SET

                                if (checkTimer > 0) {
                                    checkTimer = 0

                                    downloadTimer = setInterval(function() {
                                        timeleft++;
                                        document.getElementById("countdowntimer").textContent = timeleft;
                                        // TYPING SPEED
                                        wpmspeed = speed / timeleft;
                                        document.getElementById("typeSpeed").textContent = speed / timeleft;
                                        //mywpmspeed = wpmspeed;
                                        if (mywpmspeed < wpmspeed) {

                                            mywpmspeed = wpmspeed;
                                            //document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed; 
                                        }
                                        document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed;
                                        //if(timeleft >= 40)
                                        if (speed == textLength)
                                            clearInterval(downloadTimer);

                                    }, 1000);
                                }
                                //if(checkmywpm == 1){

                                //document.getElementById("myWPM").innerHTML = mywpm + wpmspeed; 
                                //}
                                //document.getElementById("myWPM").innerHTML = mywpm + mywpmspeed;

                            }


                            function showWPM() {


                                if (window.XMLHttpRequest) {
                                    // code for IE7+, Firefox, Chrome, Opera, Safari
                                    xmlhttp = new XMLHttpRequest();
                                } else {
                                    // code for IE6, IE5
                                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                }
                                xmlhttp.onreadystatechange = function() {
                                    if (this.readyState == 4 && this.status == 200) {
                                        //document.getElementById("txtHint").innerHTML = this.responseText;
                                        var rspncWPM = this.responseText;
                                        // Passage Finding
                                        //var posStart = rspnc.indexOf("Content");
                                        //posStart = posStart+9;
                                        //var posEnd = rspnc.indexOf("About");
                                        //posEnd = posEnd-5;

                                        // Passage Content
                                        //var text = "";
                                        //var i;
                                        //for (i = posStart; i <= posEnd; i++) {
                                        //	text += rspnc[i];
                                        //}
                                        document.getElementById("demoWPM").innerHTML = rspncWPM;
                                    }
                                };

                                xmlhttp.open("GET", "getWPM.php", true);
                                xmlhttp.send();

                            }

                            function removeWPM() {

                                if (window.XMLHttpRequest) {
                                    // code for IE7+, Firefox, Chrome, Opera, Safari
                                    xmlhttp = new XMLHttpRequest();
                                } else {
                                    // code for IE6, IE5
                                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                }
                                xmlhttp.onreadystatechange = function() {
                                    if (this.readyState == 4 && this.status == 200) {
                                        var rspncWPM = this.responseText;
                                        rspncWPM = "";
                                        document.getElementById("demoWPM").innerHTML = rspncWPM;
                                    }
                                };

                                xmlhttp.open("GET", "getWPM.php", true);
                                xmlhttp.send();

                            }




                            function showRecentWPM() {


                                if (window.XMLHttpRequest) {
                                    // code for IE7+, Firefox, Chrome, Opera, Safari
                                    xmlhttp = new XMLHttpRequest();
                                } else {
                                    // code for IE6, IE5
                                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                }
                                xmlhttp.onreadystatechange = function() {
                                    if (this.readyState == 4 && this.status == 200) {
                                        var rspncWPM = this.responseText;

                                        document.getElementById("recentWPM").innerHTML = rspncWPM;
                                    }
                                };

                                xmlhttp.open("GET", "getRecentWPM.php", true);
                                xmlhttp.send();

                            }

                            function removeRecentWPM() {

                                if (window.XMLHttpRequest) {
                                    // code for IE7+, Firefox, Chrome, Opera, Safari
                                    xmlhttp = new XMLHttpRequest();
                                } else {
                                    // code for IE6, IE5
                                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                }
                                xmlhttp.onreadystatechange = function() {
                                    if (this.readyState == 4 && this.status == 200) {
                                        var rspncWPM = this.responseText;
                                        rspncWPM = "";
                                        document.getElementById("recentWPM").innerHTML = rspncWPM;
                                    }
                                };

                                xmlhttp.open("GET", "getWPM.php", true);
                                xmlhttp.send();

                            }
							
							
							function saveToDB(str) {

                                    if (window.XMLHttpRequest) {
                                        // code for IE7+, Firefox, Chrome, Opera, Safari
                                        xmlhttp = new XMLHttpRequest();
                                    } else {
                                        // code for IE6, IE5
                                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                    }
                                    xmlhttp.onreadystatechange = function() {
                                        if (this.readyState == 4 && this.status == 200) {
                                           // document.getElementById("myData").innerHTML = this.responseText;
                                            
                                        }
                                    };
									//document.getElementById("myData").innerHTML = source;
                                    xmlhttp.open("GET", "saveToDB.php?q=" + str + "&r=" + source, true);
                                    xmlhttp.send();
                                source = "";
								//document.getElementById("myData").innerHTML = "hi";
                            }

							
							function showMyWPM() {


                                if (window.XMLHttpRequest) {
                                    // code for IE7+, Firefox, Chrome, Opera, Safari
                                    xmlhttp = new XMLHttpRequest();
                                } else {
                                    // code for IE6, IE5
                                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                }
                                xmlhttp.onreadystatechange = function() {
                                    if (this.readyState == 4 && this.status == 200) {
                                        var rspncWPM = this.responseText;

                                        document.getElementById("myData").innerHTML = rspncWPM;
                                    }
                                };

                                xmlhttp.open("GET", "getMyWPM.php", true);
                                xmlhttp.send();

                            }

                            function removeMyWPM() {

                                if (window.XMLHttpRequest) {
                                    // code for IE7+, Firefox, Chrome, Opera, Safari
                                    xmlhttp = new XMLHttpRequest();
                                } else {
                                    // code for IE6, IE5
                                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                }
                                xmlhttp.onreadystatechange = function() {
                                    if (this.readyState == 4 && this.status == 200) {
                                        var rspncWPM = this.responseText;
                                        rspncWPM = "";
                                        document.getElementById("myData").innerHTML = rspncWPM;
                                    }
                                };

                                xmlhttp.open("GET", "getWPM.php", true);
                                xmlhttp.send();

                            }
							
							
                        </script>

                    </div>

                    <div class="card">
                        <h3>Bangla keyboards layouts...</h3>
                        <div class="slideshow-container" style="height:350px;">

                            <div class="slideshow-container">

                                <div class="mySlides fade">
                                    <div class="numbertext">1 / 3</div>
                                    <img src="Avro.png" style="width:100%">
                                    <div class="text">Avro_Phonetic_Keyboard_Layout</div>
                                </div>

                                <div class="mySlides fade">
                                    <div class="numbertext">2 / 3</div>
                                    <img src="Bijoy.png" style="width:100%">
                                    <div class="text">Bijoy_Bayanno_Keyboard_Layout</div>
                                </div>

                                <div class="mySlides fade">
                                    <div class="numbertext">3 / 3</div>
                                    <img src="Bangladesh_National_Keyboard_Layout.png" style="width:100%">
                                    <div class="text">Bangladesh_National_Keyboard_Layout</div>
                                </div>

                            </div>
                            <br>

                            <div style="text-align:center">
                                <span class="dot"></span>
                                <span class="dot"></span>
                                <span class="dot"></span>
                            </div>

                            <script>
                                var slideIndex = 0;
                                showSlides();

                                function showSlides() {
                                    var i;
                                    var slides = document.getElementsByClassName("mySlides");
                                    var dots = document.getElementsByClassName("dot");
                                    for (i = 0; i < slides.length; i++) {
                                        slides[i].style.display = "none";
                                    }
                                    slideIndex++;
                                    if (slideIndex > slides.length) {
                                        slideIndex = 1
                                    }
                                    for (i = 0; i < dots.length; i++) {
                                        dots[i].className = dots[i].className.replace(" active", "");
                                    }
                                    slides[slideIndex - 1].style.display = "block";
                                    dots[slideIndex - 1].className += " active";
                                    setTimeout(showSlides, 2000); // Change image every 2 seconds
                                }

                            </script>



                        </div>
                    </div>
                </div>
            </div>
            <div class="rightcolumn">
                <div class="card">
                    <font color="red">
                    <h4>
                        <?php echo $_SESSION['username']; ?>
                    </h4>
                    </font>
                    <img src="login.png" alt="Mountain View" width="100" height="100">

                    
					
                    <button onclick="document.getElementById('myData').innerHTML = removeMyWPM()" style="width:auto;">Hide progress</button>
                    <button onclick="document.getElementById('myData').innerHTML = showMyWPM()" style="width:auto;">Show progress</button>
                    <font color="blue">
                    <p id="myData"> </p>

                </div>

                <div class="topnav">
                    <font color="red">
                        <h3>Top Users</h3>
                    </font>





                    <button onclick="document.getElementById('demoWPM').innerHTML = showWPM()" style="width:auto;">Show</button>
                    <button onclick="document.getElementById('demoWPM').innerHTML = removeWPM()" style="width:auto;">Hide</button>
                    <button onclick="document.getElementById('demoWPM').innerHTML = showWPM()" style="width:auto;">Refresh</button>
                    <font color="blue">
                        <p id="demoWPM"></p>
                    </font>

                </div><br>
                <div class="topnav">
                    <font color="red">
                        <h3>Recent Users</h3>
                    </font>





                    <button onclick="document.getElementById('recentWPM').innerHTML = showRecentWPM()" style="width:auto;">Show</button>
                    <button onclick="document.getElementById('recentWPM').innerHTML = removeRecentWPM()" style="width:auto;">Hide</button>
                    <button onclick="document.getElementById('recentWPM').innerHTML = showRecentWPM()" style="width:auto;">Refresh</button>
                    <font color="blue">
                        <p id="recentWPM"></p>
                    </font>

                </div>
				<div class="card">
	  <iframe style="height: 650px; 
    width: 290px;
    background-color: powderblue" src="formpage.html" name="targetframe"  frameborder="0" >
    </iframe>
    </div>
            </div>
    </body>

    </html>
